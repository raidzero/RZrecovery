#!/sbin/sh

echo msc_adb > /dev/usb_device_mode
