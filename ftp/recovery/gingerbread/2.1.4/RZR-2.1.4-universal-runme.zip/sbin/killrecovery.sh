#!/sbin/sh
mkdir -p /sd-ext
[ -e /cache/recovery/command ] && rm /cache/recovery/command
[ -e /cache/update.zip ] && rm /cache/update.zip
touch /tmp/.ignorebootmessage
busybox nohup /sbin/recovery &
exit 1
